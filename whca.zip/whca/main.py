import numpy as np
from utils import DistanceMethod, CostMapGrid
from visualization import Graph
from node import Node
from agent import Agent
from RRAStar import RRAStar
from whca import WHCA
import random
import copy
import cv2
from visualization import Graph



def generate_obstacles(shape, number, constraints=[]):
    index_range = shape - 1
    random.seed(1)
    obstacles = copy.deepcopy(constraints)
    positions = []
    for i in range(number):
        x: int
        y: int
        available = False
        while not available:
            x = round(index_range * random.random())
            y = round(index_range * random.random())
            available = True
            for obs in obstacles:
                if obs[0] == x and obs[1] == y:
                    available = False
        positions.append([x, y])
        obstacles.append([x, y])
    return positions


def test_whca_grid():
    shape = 32
    display = Graph(shape)
    obstacles = generate_obstacles(shape, 50)

    starts = generate_obstacles(shape, 50, obstacles)
    goals = generate_obstacles(shape, 50, obstacles+starts)
    cost_map = CostMapGrid(shape, obstacles)

    whca = WHCA(starts, goals, cost_map, window=5, visualization=True)
    agent_solver = whca.run()

    trajectories = []
    for i in range(len(agent_solver)):
        print("agent {}: ".format(i))
        path = []
        for pos in agent_solver[i][0].trajectory:
            path.append(pos.position)
            print("{}".format(pos.position), end="; / ")
        trajectories.append(copy.deepcopy(path))
        print(" ")

    display.show_map(obstacles,starts,goals,trajectories)



if __name__ == "__main__":
    print("start testing")
    # test_RRAStar()
    test_whca_grid()
