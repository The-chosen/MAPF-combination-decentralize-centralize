# Required Packages:
matplotlib                3.1.3
numpy                     1.18.1

# Instructions:
```buildoutcfg
    python main.py
```

# Testing:
You can change the functions in main.py to test different files
